<?php 


phpinfo();
