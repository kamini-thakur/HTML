<?php
/*	
*	---------------------------------------------------------------------
*	MNKY Overlay Sidebar
*	--------------------------------------------------------------------- 
*/
?>
	
<div id="overlay-sidebar">
	<?php dynamic_sidebar( 'overlay-sidebar' ); ?>
</div>
