jQuery(document).ready(function($) {
	"use strict";
	
		jQuery('.plugin-notice, .not-active-bg').show();
	
});