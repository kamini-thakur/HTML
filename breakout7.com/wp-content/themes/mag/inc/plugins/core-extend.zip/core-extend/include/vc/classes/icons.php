<?php
class WPBakeryShortCode_Mnky_Icons extends WPBakeryShortCode {

}