<?php
/**
 * Template for display wrap end of courses list
 *
 * @author  ThimPress
 * @version 1.1
 */
?>
</div>