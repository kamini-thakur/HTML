<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */
defined( 'ABSPATH' ) || exit();
learn_press_display_message( __( 'This is private area. Please login to view this.', 'cryptic' ) );