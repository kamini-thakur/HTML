{{header}}

Hi <strong>{{order_user_name}}</strong>,

<p>Order placed at <strong>{{site_title}}</strong><p>

{{order_items_table}}

<p>View order: <a href="{{order_detail_url}}">{{order_number}}</a>
	
{{footer}}
