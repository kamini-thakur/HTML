<?php
/**
 * Created by PhpStorm.
 * User: Tu
 * Date: 11/16/2015
 * Time: 2:03 PM
 */
?>
						</td>
					</tr>
					<tr>
						<td>
							<?php echo  wpautop( wp_kses_post( wptexturize( $footer_text ) ) ); ?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</div>
