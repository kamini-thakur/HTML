{{header}}

{{order_items_table}}

<p>View order: <a href="{{order_detail_url}}">{{order_number}}</a></p>

{{footer}}