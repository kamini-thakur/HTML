{{header}}

<p>New order placed by <strong>{{order_user_name}}</strong></p>

{{order_items_table}}

<p>View order: <a href="{{order_edit_url}}">{{order_number}}</a>

{{footer}}