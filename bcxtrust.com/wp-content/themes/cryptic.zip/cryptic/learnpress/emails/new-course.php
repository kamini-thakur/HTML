{{header}}

<p>A new course <a href="{{course_edit_url}}">{{course_name}}</a> has been submitted is waiting for your approval</p>

<p>Please review course</p>

{{footer}}