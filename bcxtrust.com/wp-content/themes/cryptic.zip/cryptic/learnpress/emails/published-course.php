{{header}}

<p>Dear <strong>{{course_user_name}},</strong></p>

<p>Congratulation! The course you created here <a href="{{course_edit_url}}">{{course_name}}</a> is available now.</p>

<p>Click <a href="{{course_url}}">{{course_url}}</a> to view your course.</p>

{{footer}}