{{header}}

<p>You have enrolled in the course <a href="{{course_url}}">{{course_name}}</a>.</p>

<p>Please <a href="{{login_url}}">login</a> and start learning now.</p>

{{footer}}