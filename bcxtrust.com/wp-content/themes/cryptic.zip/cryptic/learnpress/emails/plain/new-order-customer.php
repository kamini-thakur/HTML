== {{email_heading}} ==

Hi {{order_user_name}},

Order placed at {{site_title}}

{{order_items_table}}

View order ({{order_number}}): {{order_detail_url}}
	
{{footer_text}}