== {{email_heading}} ==

Dear {{course_user_name}},

Unfortunately! The course you created here {{course_edit_url}} ({{course_name}}) isn't ready for sale now.

Please login {{login_url}} and update your course to meet our minimum requirements for quality and/or our policies

{{footer_text}}