== {{email_heading}} ==

New order placed by {{order_user_name}}

{{order_items_table}}

View order: {{order_edit_url}}
 
== {{footer_text}} ==