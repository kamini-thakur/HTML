<?php
/**
 * Template for displaying the div for ending of column display at the left
 *
 * @author  ThimPress
 * @package LearnPress
 * @version 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

</div>
<!-- // quiz summary left column -->