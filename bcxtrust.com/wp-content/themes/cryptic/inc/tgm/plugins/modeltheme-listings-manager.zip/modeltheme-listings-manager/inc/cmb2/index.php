<?php // Silence is golden.
