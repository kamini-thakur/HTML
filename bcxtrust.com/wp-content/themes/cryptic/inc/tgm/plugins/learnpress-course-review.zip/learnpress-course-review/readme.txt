=== LearnPress - Course Review ===  
Contributors: thimpress, tunnhn, kendy73, leehld
Donate link:  
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses  
Requires at least: 3.8  
Tested up to: 4.9.1  
Stable tag: 2.2
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

LearnPress Course Review - An extension plugin for LearnPress.  

== Description == 

**LearnPress** is a <a href="http://thimpress.com/learnpress">WordPress LMS Plugin</a> by ThimPress.

LearnPress Course Review bring review feature to your course. Now, student can rate and give review for the course they take on a LearnPress site.  

Review add-on for LearnPress is using on some WordPress Themes: [Education WordPress Theme](http://themeforest.net/item/education-wordpress-theme-education-wp/14058034?utm_source=wporg&utm_medium=course-review&ref=thimpress&utm_campaign=learnpress "Education WordPress Theme") and [LMS WordPress Theme](http://themeforest.net/item/lms-wordpress-theme-elearning-wp/11797847??utm_source=wporg&utm_medium=course-review&ref=thimpress&utm_campaign=learnpress "LMS WordPress Theme"), more is coming.

**Other free add-ons for LearnPress are available in WordPress:**  

- <a href="https://wordpress.org/plugins/learnpress-wishlist/" target="_blank">LearnPress Wishlist</a> - add courses to a wishlist for students.  
- <a href="https://wordpress.org/plugins/learnpress-course-review/" target="_blank">LearnPress Course Review</a> - review course for enrolled students.  
- <a href="https://wordpress.org/plugins/learnpress-import-export/" target="_blank">LearnPress Import Export</a> - export or import course or courses out-of-box.  
- <a href="https://wordpress.org/plugins/learnpress-prerequisites-courses/" target="_blank">LearnPress Prerequisites Courses</a> - require student to pass some courses in order to enroll other course.  
- <a href="https://wordpress.org/plugins/learnpress-bbpress" target="_blank">LearnPress bbPress</a> - add bbPress Forum support for LearnPress.  
- <a href="https://wordpress.org/plugins/learnpress-buddypress" target="_blank">LearnPress BuddyPress</a> - add BuddyPress support for LearnPress.  

**Premium Plugins (add-ons) for LearnPress WordPress LMS Plugin**

- <a href="http://thimpress.com/shop/certificates-add-on-for-learnpress/" target="_blank">Certificates add-on for LearnPress</a> - adding drag & drop certificates builder as well as selecting designed certificate for each LMS course, your student will get particular certificate when they finished a course.  
- <a href="http://thimpress.com/shop/co-instructors-add-on-for-learnpress/" target="_blank">Co-instructors add-on for LearnPress</a> - multiple instructors support for each LMS course.  
- <a href="http://thimpress.com/shop/collections-add-on-for-learnpress/"  target="_blank">Collections add-on for LearnPress</a> - making LMS courses collection by selecting number of courses, this is helpful if you want to combine multiple LMS courses into a collection for a group of skills.  
- <a href="http://thimpress.com/shop/stripe-add-on-for-learnpress/"  target="_blank">Stripe Payment method for LearnPress</a> - Stripe payment method for LearnPress WordPress LMS Plugin.  
- <a href="http://thimpress.com/shop/woocommerce-add-on-for-learnpress/"  target="_blank">WooCommerce add-on for LearnPress</a> - using WooCommerce as payment gateway for LearnPrss WordPress LMS Plugin.

== Installation ==  

**From your WordPress dashboard**  
1. Visit 'Plugin > Add new'.  
2. Search for 'LearnPress Course Review'.  
3. Activate LearnPress from your Plugins page.  

**From WordPress.org**  
1. Search, select and download LearnPress Course Review.  
2. Activate the plugin through the 'Plugins' menu in WordPress Dashboard.

== Frequently Asked Questions ==

Check out <a href="http://docs.thimpress.com/learnpress" target="_blank">LearnPress</a> sites.  

== Screenshots ==  

1. LearnPress Course Review screenshot.  

== Changelog ==

= 2.2 =
+ Fixed bug cannot review course have commented
+ Add notices upgrading addon for LP 3.0

= 2.1 =
+ Allow all user and guest user can view reviewed
+ Only allow enrolled user can write new review

= 2.0.1 =
+ Changed text domain to learnpress

= 2.0 =
+ Updated to be compatible with LearnPress 2.0

= 1.1 =
+ Fixed comments do not show in admin

= 1.0 =
+ Compatible with LearnPress version 1.0

= 0.9.1 =  
+ Updated languages file
+ Fixed PHP5 version 5.3.x error

= 0.9.0 =  
+ The first beta release.

== Upgrade Notice ==  
Later :)

== Other note ==  
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.  
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>  