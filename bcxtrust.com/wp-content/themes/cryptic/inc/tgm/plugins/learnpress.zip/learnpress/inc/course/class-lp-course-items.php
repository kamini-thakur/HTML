<?php

class LP_Course_Items {
	protected static $_course_items = array();

	public function get_item( $item, $return = 'object' ) {

	}
}