</div>
</div>
<script type="text/javascript">
	jQuery(function ($) {
		LP.sortableQuestionAnswers($('#learn-press-question-<?php echo $this->id;?>'));
	})
</script>