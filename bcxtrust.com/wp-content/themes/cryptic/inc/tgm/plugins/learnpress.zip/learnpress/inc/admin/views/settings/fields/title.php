<tr class="header-form">
	<th colspan="2"><h3 class="lp-group-title"><?php echo esc_html( $options['title'] ) ?></h3></th>
</tr>