<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstallModel extends Model
{
    //
}
