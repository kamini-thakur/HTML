<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Shopify Api
    |--------------------------------------------------------------------------
    |
    | This file is for setting the credentials for shopify api key and secret.
    |
    */

    'key' => env("SHOPIFY_APIKEY", "e6ea73e73652e2c55a75fb3db5795de0"),
    'secret' => env("SHOPIFY_SECRET", "837216e07d3c643b1311d5de33ad4606")
];