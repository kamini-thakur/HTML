<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Input;
use Shopify;
use DB;
use Response; 

class GetWebhooksController extends Controller
{
    public function uninstall(Request $request)  
    {
    	try
    	{
    		$data = file_get_contents('php://input');
    		// $path = storage_path() .'/app/files/Uninstall.txt';
			// $fh=fopen('Uninstall.txt', 'w');

			// fwrite($fh,$data);
			$Array    =json_decode($data);
			mail("kamini_thakur@esferasoft.com","uninstall",'data='.$data);
			$_DOMAIN  =$_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
			// fwrite($fh, $_DOMAIN);

			mail("kamini_thakur@esferasoft.com","uninstall",'domain='.$_DOMAIN);

			DB::table('app_data')->where('shop_domain', $_DOMAIN)->delete();
    	}
    	catch (\Exception $e) 
    	{
            echo $uninstall_response = $e->getMessage();
        }
    }  
    public function productDelete(Request $request)  
    {
    	try
    	{
    		$data = file_get_contents('php://input');
			// $fh=fopen('prodDelete.txt', 'w');

			// fwrite($fh,$data);
			$Array    =json_decode($data);
			mail("kamini_thakur@esferasoft.com","uninstall",'data='.$data);
			$_DOMAIN  =$_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
			// fwrite($fh, $_DOMAIN);

			$productId = $Array->id;
			// fwrite($fh, $productId);

			mail("kamini_thakur@esferasoft.com","uninstall",'data='.$data.'productId='.$productId);

			DB::table('product_details')->where([['shop_domain', $_DOMAIN],['productID', $productId]])->delete();
    	}
    	catch (\Exception $e) 
    	{
            echo $uninstall_response = $e->getMessage();
        }
    } 
}
