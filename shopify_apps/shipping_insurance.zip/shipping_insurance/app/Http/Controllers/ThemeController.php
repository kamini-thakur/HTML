<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Shopify;
use DB;
use Session;
use Redirect;

class ThemeController extends Controller
{
    public function __construct()
    {
        $this->middleware('cors');
        $this->middleware('AppInstalled');
    }
    public function index(Request $request)  
    {
    	$shopUrl = $request->session()->get('shop');
        $accessToken = DB::table('app_data')->where('shop_domain', $shopUrl)->pluck('accress_token')->first();
        $shopify = Shopify::setShopUrl($shopUrl)->setAccessToken($accessToken);
        $app_url = env("APP_URL");

        $addScript = array 
        (
            'event'=> "onload",
            'src'=> $app_url."/js/insurance.js"
        );   

        try{
            $enable_app = DB::table('app_data')->where('shop_domain', $shopUrl)->pluck('enable_app')->first();
            if ($enable_app === 1) {
                $script_response = $shopify->post("/admin/script_tags.json", ["script_tag"=>$addScript]);
                if(isset($script_response['id']))
                {
                    return redirect()->action('ProductController@editProduct')->with('successMsg', 'Product created successfully');
                }
            }
        }
        catch (\Exception $e) {
            $script_response = $e->getMessage();
        }

    }
    public function getShippingProduct(Request $request)  
    {
        $shopUrl = $_GET['shopDomain'];
        $variantID = DB::table('product_details')->where('shopDomain', $shopUrl)->pluck('variantID')->first();
        return $variantID;
    }
}
