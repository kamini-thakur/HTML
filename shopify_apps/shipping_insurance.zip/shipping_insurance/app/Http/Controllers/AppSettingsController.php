<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Shopify;
use DB;
use Session;
use Redirect;

class AppSettingsController extends Controller
{
    public function __construct()
    {
        $this->middleware('AppInstalled');
    }
    public function index(Request $request)  
    {
        $shopUrl = $request->session()->get('shop');
        $enable_app = DB::table('app_data')->where('shop_domain', $shopUrl)->pluck('enable_app')->first();
        return view('settings', ['app_enable_settings' => $enable_app]);
    }
    public function changeSettings(Request $request)  
    {
        $enable_status = $_GET['Status'];
        // echo $enable_status = $request->enable_disable;
        $shopUrl = $request->session()->get('shop');
        // $accessToken = DB::table('app_data')->where('shop_domain', $shopUrl)->pluck('accress_token')->first();

        DB::table('app_data')
                ->where('shop_domain', $shopUrl)
                ->update(['enable_app'=> $enable_status]);

        // return view('settings');
    }
}
