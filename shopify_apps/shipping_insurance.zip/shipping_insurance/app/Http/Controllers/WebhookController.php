<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Input;
use Shopify;
use DB;
use Response; 
use Session;
use Redirect;

class WebhookController extends Controller
{
	public function __construct()
    {
        $this->middleware('AppInstalled');
    }
    public function index(Request $request)  
    {
    	try
    	{
            $shopUrl = $request->session()->get('shop');
	        $accessToken = DB::table('app_data')->where('shop_domain', $shopUrl)->pluck('accress_token')->first();
	        $shopify = Shopify::setShopUrl($shopUrl)->setAccessToken($accessToken);

	        //////////// Create app uninstallation webhook ////////////
	    	$url ='/admin/webhooks.json';
	    	$baseURL = env("APP_URL");

	    	$uninstall = $baseURL.'/uninstall';
			$uninstallArray = $shopify->get('/admin/webhooks.json',["address"=>$uninstall]);
			$uninstallArray  = json_decode($uninstallArray,true);

		    $uninstallMeta = array
		    (
		            "topic"=> "app/uninstalled",
		            "address"=> $baseURL."/uninstall",
		            "format"=>"json"
		    );

		    if (empty($uninstallArray))
		    {     
		        $shopify->post($url, ["webhook"=>$uninstallMeta]);
		    }

		    // $shopify->delete("/admin/webhooks/286450942052.json");

		    //////////// Create product deletion webhook ////////////

		    $productDelete = $baseURL.'/productDelete';
			$productArray = $shopify->get('/admin/webhooks.json',["address"=>$productDelete]);
			$productArray  = json_decode($productArray,true);

		    $prodMeta = array 
		    (
		        "topic"=> "products/delete",
		        "address"=> $baseURL."/productDelete",
		        "format"=>"json"
		    );
	    
	        if (empty($productArray)) {
	            $shopify->post($url,["webhook"=>$prodMeta]); 
	        }
	    }
	    catch (\Exception $e) {
            $webhooks_response = $e->getMessage();
        }
        return redirect()->action('ProductController@index')->with('successMsg', 'Thanks for installing APP'); 
	}

}
