<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Shopify Api
    |--------------------------------------------------------------------------
    |
    | This file is for setting the credentials for shopify api key and secret.
    |
    */

    'key' => env("SHOPIFY_APIKEY", "e99c5ba63bca791842879bc0da78c6c7"),
    'secret' => env("SHOPIFY_SECRET", "28e4a26ad2282346f96afd157537a08a")
];