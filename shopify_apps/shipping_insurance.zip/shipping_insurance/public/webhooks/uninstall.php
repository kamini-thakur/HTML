<?php

/*      getting the domain from which request is made      */

$data = file_get_contents('php://input');
$fh=fopen('Uninstall.txt', 'w');

fwrite($fh,$data);
$Array    =json_decode($data);

$_DOMAIN  =$_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
fwrite($fh, $_DOMAIN);


?>

