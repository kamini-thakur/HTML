var loadScript = function(){

	function getCart(insuranceID)
	{ 
		$.ajax({
		      url: '/cart.js',
		      dataType: 'json',
		      type: 'get',
		      success: cartResponse,
		      error: function(XMLHttpRequest) {
		        var response = eval('(' + XMLHttpRequest.responseText + ')');
		        response = response.description;
				console.log(response);
		      }
		});
	}
	function sendRequest(shopURL)
	{ 
	    $.ajax({
	        type: "GET",
	        url: "https://shipping-insurance.ecommvantage.com/getShippingInsurance",
	        data: { shopDomain: shopURL },
	        success: function(response) {
	        	productData['variant_id'] = response; 
	        	var removeElm = $("a[href$='&quantity=0']");
	        	var insurance_variant = $("a[href$='?variant="+productData['variant_id']+"']");
	        	$(insurance_variant).attr('href','');
	        	$('[id^=Updates_'+productData['variant_id']+']').hide().parents('li,tr,div.cart__row').find(removeElm).hide(); 
	        	$('[id^=updates_'+productData['variant_id']+']').hide().parents('li,tr,div.cart__row').find(removeElm).hide(); 
	        	getCart(productData['variant_id']);
	        },
	        error: function(XMLHttpRequest) {
		        var response = eval('(' + XMLHttpRequest.responseText + ')');
			    response = response.description;
			    console.log(response);
			}
	    });	 
    }
    function cartResponse(cartData) {

		productData['cartItemsLength'] = cartData.items.length;
		var insuranceID = productData['variant_id'];
		var line_items = cartData.items;
		productData['shippingInsuranceAttr'] = cartData.attributes.shippingInsurance;
		productData['shipping_insurance_in_cart']=0;
		for (var i = 0; i < line_items.length; i++) {
		    var cartItemsID = line_items[i].variant_id;
		    if (cartItemsID == insuranceID)
		    {
		        productData['shipping_insurance_in_cart'] = line_items[i].quantity;
		        break;
		    }		 
		}  
   
		var cartItemsLength = productData['cartItemsLength'];
		var shippingInsuranceAttr = productData['shippingInsuranceAttr'];
		var shipping_insurance_in_cart = productData['shipping_insurance_in_cart'];

		if($('body').hasClass('js-drawer-open') && shippingInsuranceAttr)
		{ alert('hi');
			var html = '<div id="add-shipping-insurance" style="clear: left; margin: 30px 0" class="clearfix rte"><p><input type="hidden" name="attributes[shippingInsurance]" value="" /><input id="shippingInsurance" type="checkbox" name="attributes[shippingInsurance]" value="yes" checked="checked" style="float: none" /><label for="shippingInsurance" style="display:inline; padding-left: 5px; float: none;">Buy shipping insurance.</label></p></div>';
			$('#CartDrawer').find('.ajaxcart__product').last().append(html);
		}

		// alert('cartItemsLength='+cartItemsLength+' shippingInsuranceAttr='+shippingInsuranceAttr+" shipping_insurance_in_cart="+shipping_insurance_in_cart);
		
		// If we have nothing but shipping insurance item in the cart.
		if (cartItemsLength == 1 && shipping_insurance_in_cart > 0 ) {
			$(function() {
			  Shopify.Cart.ShippingInsurance.remove();
			});
		}
		// If we have more than one shipping insurance item in the cart.
		else if (shipping_insurance_in_cart > 1 ){
			$(function() { 
			  Shopify.Cart.ShippingInsurance.set();
			});
		}
		// If we have a shipping insurance item in the cart but our shippingInsurance cart attribute has not been set.
		else if (shipping_insurance_in_cart > 0 && shippingInsuranceAttr == '' ) {
			$(function() { 
			  Shopify.Cart.ShippingInsurance.set();
			});
		}
		// If we have no shipping insurance item in the cart but our shippingInsurance cart attribute has been set.
		else if (shipping_insurance_in_cart == 0 && shippingInsuranceAttr) {
			$(function() { 
			  Shopify.Cart.ShippingInsurance.set();
			});
		}

		if (shippingInsuranceAttr && shippingInsuranceAttr != '') 
		{ 
			var html = '<div id="add-shipping-insurance" style="clear: left; margin: 30px 0" class="clearfix rte"><p><input type="hidden" name="attributes[shippingInsurance]" value="" /><input id="shippingInsurance" type="checkbox" name="attributes[shippingInsurance]" value="yes" checked="checked" style="float: none" /><label for="shippingInsurance" style="display:inline; padding-left: 5px; float: none;">Buy shipping insurance.</label></p></div>';
		}
		else
		{
			var html = '<div id="add-shipping-insurance" style="clear: left; margin: 30px 0" class="clearfix rte"><p><input type="hidden" name="attributes[shippingInsurance]" value="" /><input id="shippingInsurance" type="checkbox" name="attributes[shippingInsurance]" value="yes" style="float: none" /><label for="shippingInsurance" style="display:inline; padding-left: 5px; float: none;">Buy shipping insurance.</label></p></div>';
		}
		
		if ($('form.cart').find("table").length > 0) 
		{ 	
			// alert('1st if');
			$('form.cart').find('table').after(html);
		}
		else if ($('form.cart').find(".cart__row").length > 0) 
		{   
			// alert('2nd if');
			$('form.cart').find('.cart__row').last().prepend(html);
		}
		else if ($('form#cart'))
		{ 
			// Themes like retina
			var pageURL = window.location.href;
			if(pageURL.indexOf('/cart') != -1)
			{
				$("form[action='/cart']").append(html);
			}
			$('form#cart').find('.cart_item').last().append(html);
		}
		else
		{
			$("form[action='/cart']").append(html);
			console.log("Can't find selector to append data");
		}

		if ($('#CartDrawer')) 
		{
			var cartDrawer = setInterval(CartDrawer, 1000);
			function CartDrawer()
			{
				// alert('CartDrawer');
			 	$($('#CartDrawer').find('form').length > 0)
			 	{
			 		$('#CartDrawer').find('.ajaxcart__product').last().append(html);
			 		if($('#CartDrawer').find('#add-shipping-insurance').length > 0)
			 		{ 
			 			// alert('cleared');
			 			clearInterval(cartDrawer);
			 		}
			 	}
			}
		}
	}

	var pageURL = window.location.href;
	var shopURL = document.domain;

	productData = []; 

	var shipping_insurance_in_cart = 0;
	Shopify.Cart = Shopify.Cart || {};
	Shopify.Cart.ShippingInsurance = {};

	sendRequest(shopURL);

	Shopify.Cart.ShippingInsurance.set = function() { 
	  	  	var data = "updates["+productData['variant_id']+"]=1&attributes[shippingInsurance]=true";
			
		    $.ajax({
			    type: 'POST',
			    url: '/cart/update.js',
			    data: data, 
			    dataType: 'json',
			    success: function() { 
			    	location.href = '/cart'; 
			    }
		    });
	}

	Shopify.Cart.ShippingInsurance.remove = function() { 
			var data = "updates["+productData['variant_id']+"]=0&attributes[shippingInsurance]="+'';
	  		      
		    $.ajax({
			    type: 'POST',
			    url: '/cart/update.js', 
			    data: data, 
			    dataType: 'json',
			    success: function() { 
			    	location.href = '/cart'; 
			    }
		    });
	} 

	// When the shippingInsurance checkbox is checked or unchecked.
	$(function() {
		// $('#updates_'+productData['variant_id']).css('display','none');
		$(document).on('change','[name="attributes[shippingInsurance]"]', function() { 
			// alert('change');
		    if ($(this).is(':checked')) {
		      Shopify.Cart.ShippingInsurance.set();    
		    }
		    else {
		      Shopify.Cart.ShippingInsurance.remove();
		    }
		});

		// $(document).on('change','#CartDrawer', function() {
		// 		alert('chaging');
		// });

	});
};

if((typeof jQuery === 'undefined') || (parseFloat(jQuery.fn.jquery) < 1.7)) 
{	
	var headTag = document.getElementsByTagName("head")[0];
	var jqTag = document.createElement('script');
	jqTag.type = 'text/javascript';
	jqTag.src = '//code.jquery.com/jquery-3.2.1.js';
	jqTag.onload = loadScript;
	headTag.appendChild(jqTag);
}
else
{
	loadScript();
}





